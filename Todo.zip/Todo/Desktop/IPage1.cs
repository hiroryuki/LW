﻿namespace Desktop
{
    public interface IPage1
    {
        void InitializeComponent();
    }
}